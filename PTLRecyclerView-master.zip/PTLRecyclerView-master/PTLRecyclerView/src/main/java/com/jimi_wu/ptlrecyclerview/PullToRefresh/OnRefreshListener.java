package com.jimi_wu.ptlrecyclerview.PullToRefresh;

/**
 * Created by Administrator on 2016/9/21.
 */
public interface OnRefreshListener {

    /**开始刷新*/
    void onStartRefreshing();

}
