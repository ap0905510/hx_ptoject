package com.jimi_wu.ptlrecyclerview.HeaderAndFooter;

/**
 * Created by Administrator on 2016/9/30.
 */
public interface OnItemLongClickListener {

    boolean onItemLongClick(int position);

}
