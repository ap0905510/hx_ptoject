package com.jimi_wu.ptlrecyclerview.HeaderAndFooter;

/**
 * Created by Administrator on 2016/9/30.
 */
public interface OnItemClickListener {

    void OnItemClick(int position);

}
