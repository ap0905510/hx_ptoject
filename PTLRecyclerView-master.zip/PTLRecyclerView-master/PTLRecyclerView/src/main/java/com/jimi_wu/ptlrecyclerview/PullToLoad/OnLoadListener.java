package com.jimi_wu.ptlrecyclerview.PullToLoad;

/**
 * Created by Administrator on 2016/9/21.
 */
public interface OnLoadListener {

    void onStartLoading(int skip);

}
